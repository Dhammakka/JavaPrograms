package stepDefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MainSteps {
	String websiteUrl = "https://bookcart.azurewebsites.net";
	static WebDriver driver;
	String userName;

	String userName_login = "Dhammakka@Pandav";
	String password_login = "Dhammupandav1";

	HashMap<String, By> books = new HashMap<String, By>();
	List<Integer> price_books = new ArrayList<Integer>();

	@Given("User is on login page")
	public void user_is_on_login_page() {
		driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		driver.get(websiteUrl);
		driver.findElement(By.xpath("//span[text()=' Login ']")).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Login']/..")));
		System.out.println("Successfully landed on login Page");
	}

	@When("User enters valid username and password")
	public void user_enters_valid_username_and_password() {
		driver.findElement(By.id("mat-input-0")).sendKeys(userName_login);
		driver.findElement(By.cssSelector("input[ng-reflect-placeholder='Password']")).sendKeys(password_login);
	}

	@And("click on login button")
	public void click_on_login_button() {
		driver.findElement(By.xpath("//span[text()='Login']/..")).click();
	}

	@Then("User is navigated to home page")
	public void user_is_navigated_to_home_page() {
		String loggedInUserName_UI = driver
				.findElement(By.xpath("//a[@ng-reflect-menu]//span[@class='mdc-button__label']//span")).getText();
		Assert.assertEquals(loggedInUserName_UI, userName_login);
		System.out.println("Successfully logged in as : " + loggedInUserName_UI);
	}

	@And("User landed on Registration page")
	public void user_is_on_registration_page() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Register']/..")));
		driver.findElement(By.xpath("//span[text()='Register']/..")).click();

	}

	@When("User enters valid first name")
	public void user_enters_valid_first_name() {
		driver.navigate().refresh();
		driver.findElement(By.xpath("//input[@placeholder='First name']")).sendKeys("Dhammakka");
	}

	@And("User enters valid last name")
	public void user_enters_valid_last_name() {
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Pandav");
	}

	@And("User enters valid user name")
	public void user_enters_valid_user_name() {
		userName = "Pandav4Dhammakka" + (int) (Math.random() * 10000);
		driver.findElement(By.xpath("//input[@placeholder='User name']")).sendKeys(userName);
	}

	@And("user enters valid password")
	public void user_enters_valid_password() {
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("Dhammupandav1");
	}

	@And("user enters valid confirm password")
	public void user_enters_valid_confirm_password() {
		driver.findElement(By.xpath("//input[@placeholder='Confirm Password']")).sendKeys("Dhammupandav1");
	}

	@And("user clicks on valid gender button")
	public void user_clicks_on_valid_gender_button() {
		driver.findElement(By.xpath("//input[@value='Female']")).click();
	}

	@And("user clicks on register button")
	public void user_clicks_on_register_button() throws InterruptedException {
		WebElement registerButton = driver.findElement(By.xpath("//span[text()='Register']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", registerButton);
		Thread.sleep(3000);
		js.executeScript("arguments[0].click();", registerButton);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.invisibilityOf(registerButton));
	}

	@Then("User is navigated to login page")
	public void user_is_navigated_to_login_page() {
		String title = driver.findElement(By.xpath("//div[@class='mat-mdc-card-header-text']")).getText();
		Assert.assertEquals("Login", title);
		System.out.println("Successully registered : " + userName);

	}

	@When("User is able to search and add items to cart")
	public void user_is_able_to_search_and_add_items_to_cart() throws InterruptedException {
		books.put("Robbie", By.xpath("//mat-option[@ng-reflect-value='Robbie']/.."));
		books.put("Roomies", By.xpath("//mat-option[@ng-reflect-value='Roomies']/.."));
		books.put("Magic for Liars", By.xpath("//mat-option[@ng-reflect-value='Magic for Liars']/.."));
		books.put("The Chosen", By.xpath("//mat-option[@ng-reflect-value='The Chosen']/.."));
		books.put("Red Rising", By.xpath("//mat-option[@ng-reflect-value='Red Rising']/.."));

		Set<String> book_s = books.keySet();
		for (String book : book_s) {
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@placeholder='Search books or authors']")).click();
			driver.findElement(By.xpath("//input[@placeholder='Search books or authors']")).sendKeys(book);
			driver.findElement(books.get(book)).click();
			String searchedBook = driver.findElement(By.xpath("//a//strong")).getText();
			Assert.assertEquals(searchedBook, book);
			String digitsOnly = driver.findElement(By.xpath("//div//p")).getText().replaceAll("\\D+", "");
			int digits = Integer.parseInt(digitsOnly);
			digits = digits / 100;
			if (price_books.contains(digits)) {
				int i = price_books.indexOf(digits);
				int num = price_books.get(i);
				price_books.add(digits + num);
			} else {
				price_books.add(digits);
			}
			driver.findElement(By.xpath("//button[@mat-raised-button]")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@placeholder='Search books or authors']")).clear();
			System.out.println(price_books);
		}
	}

	@Then("successfully selected item should be added to the cart")
	public void successfully_selected_item_should_be_added_to_the_cart() {

		driver.findElement(By.xpath("//button[contains(@ng-reflect-router-link,'shopping')]")).click();
		List<WebElement> element = driver.findElements(By.xpath("//tr//td[2]//a"));
		for (WebElement ele : element) {
			Assert.assertTrue(books.containsKey(ele.getText()));
		}
		driver.findElement(By.xpath("//span[text()=' Clear cart ']/..")).click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()=' Continue shopping ']/..")));
	}

	@Then("Total price should be displayed in the cart correctly")
	public void total_price_should_be_displayed_in_the_cart_correctly() {
		driver.findElement(By.xpath("//button[contains(@ng-reflect-router-link,'shopping')]")).click();

		List<WebElement> element = driver.findElements(By.xpath("//tr//td[3]")); // total
		for (WebElement ele : element) {
			String digitsOnly = ele.getText().replaceAll("\\D+", "");
			int digits = Integer.parseInt(digitsOnly);
			digits = digits / 100;
			Assert.assertTrue(price_books.contains(digits));
		}

	}

	@Then("Total price should be updated in the cart correctly")
	public void total_price_should_be_updated_in_the_cart_correctly() {
		driver.findElement(By.xpath("//button[contains(@ng-reflect-router-link,'shopping')]")).click();
		List<WebElement> element = driver.findElements(By.xpath("//tr//td[5]"));
		for (WebElement ele : element) {
			String digitsOnly = ele.getText().replaceAll("\\D+", "");
			int digits = Integer.parseInt(digitsOnly);
			digits = digits / 100;
			Assert.assertTrue(price_books.contains(digits));
		}

	}

}
